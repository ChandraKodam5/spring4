package com.cv.spring4.mvc.annotation;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
/**
* @author Chandra
*/
@Controller
public class AppController {

    @GetMapping("/")
    public String home() {
        return "home";
    }
}