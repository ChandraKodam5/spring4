package com.cv.spring4.mvc.xml;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * @author Chandra
 */
@Controller
@RequestMapping("/")
public class HomeController {

	private final static Logger LOGGER = Logger.getLogger(HomeController.class);

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		LOGGER.info("In home()");
		return "home";
	}

}