package com.cv.spring4.mvc.xml;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
/**
 * @author Chandra
 */
@Controller
public class RedirectController {

	private final static Logger LOGGER = Logger.getLogger(RedirectController.class);


	@RequestMapping(value = "/finalPage", method = RequestMethod.GET)
	public String finalPage() {
		LOGGER.info("In finalPage()");
		return "final";
	}
}